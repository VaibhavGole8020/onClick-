package com.example.onclick;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import java.io.File;

public class NotesActivity extends AppCompatActivity {

    private static final String TAG = "NotesActivity";
    private TextView tvResourceInfo;
    private Button btnOpenFile, btnBack;
    private String resourcePath;
    private String resourceTitle;
    private String resourceType;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notes);

        tvResourceInfo = findViewById(R.id.tvResourceInfo);
        btnOpenFile = findViewById(R.id.btnDownloadResource);
        btnBack = findViewById(R.id.btnBack);

        // Get data from intent
        resourcePath = getIntent().getStringExtra("resourcePath");
        resourceTitle = getIntent().getStringExtra("resourceTitle");
        resourceType = getIntent().getStringExtra("resourceType");

        Log.d(TAG, "Resource Path: " + resourcePath);
        Log.d(TAG, "Resource Title: " + resourceTitle);
        Log.d(TAG, "Resource Type: " + resourceType);

        displayResourceInfo();

        btnOpenFile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFile();
            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void displayResourceInfo() {
        String info = "📄 " + resourceTitle + "\n\n" +
                "Type: " + resourceType + "\n\n" +
                "This file was uploaded by an administrator.\n\n" +
                "Tap the button below to open it.";

        tvResourceInfo.setText(info);
    }

    private void openFile() {
        if (resourcePath == null || resourcePath.isEmpty()) {
            Toast.makeText(this, "File path not available", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            // Convert file path to File object
            File file = new File(resourcePath);

            // Check if file exists
            if (!file.exists()) {
                Log.e(TAG, "File does not exist: " + resourcePath);
                Toast.makeText(this, "File not found", Toast.LENGTH_SHORT).show();
                return;
            }

            // ✅ CRITICAL: Use FileProvider to get content URI
            Uri fileUri = FileProvider.getUriForFile(
                    this,
                    "com.example.onclick.fileprovider",
                    file
            );

            String mimeType = getMimeType(resourceType, resourcePath);

            Log.d(TAG, "Opening file:");
            Log.d(TAG, "  URI: " + fileUri);
            Log.d(TAG, "  MIME: " + mimeType);

            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(fileUri, mimeType);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

            try {
                startActivity(intent);
                Log.d(TAG, "✅ File opened successfully");
            } catch (ActivityNotFoundException e) {
                Log.e(TAG, "No app found to open this file type", e);
                showChooser(fileUri, mimeType);
            }

        } catch (IllegalArgumentException e) {
            Log.e(TAG, "❌ FileProvider error", e);
            Toast.makeText(this, "Error: File path not configured correctly", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Log.e(TAG, "❌ Error opening file", e);
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void showChooser(Uri fileUri, String mimeType) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(fileUri, mimeType);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(intent, "Open with"));
        } catch (Exception e) {
            Log.e(TAG, "Chooser also failed", e);
            showPermissionError();
        }
    }

    private void showPermissionError() {
        tvResourceInfo.setText("⚠️ Permission Error\n\n" +
                "Unable to access this file. This can happen when:\n\n" +
                "• The file was uploaded in a previous session\n" +
                "• App was reinstalled\n" +
                "• File permissions expired\n\n" +
                "Solution: Ask the administrator to re-upload this file.");

        Toast.makeText(this, "File access denied - admin needs to re-upload",
                Toast.LENGTH_LONG).show();
    }

    private String getMimeType(String fileType, String path) {
        // Try to determine from file type first
        if (fileType != null) {
            switch (fileType.toUpperCase()) {
                case "PDF": return "application/pdf";
                case "DOC": return "application/msword";
                case "IMAGE": return "image/*";
            }
        }

        // Fallback to path-based detection
        if (path != null) {
            String lowerPath = path.toLowerCase();
            if (lowerPath.contains("pdf")) return "application/pdf";
            if (lowerPath.contains("docx")) return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
            if (lowerPath.contains("doc")) return "application/msword";
            if (lowerPath.contains("jpg") || lowerPath.contains("jpeg")) return "image/jpeg";
            if (lowerPath.contains("png")) return "image/png";
        }

        // Generic fallback
        return "*/*";
    }
}
