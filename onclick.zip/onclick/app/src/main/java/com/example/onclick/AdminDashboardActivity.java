package com.example.onclick;

import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

public class AdminDashboardActivity extends AppCompatActivity {

    private ListView listViewResources;
    private Button btnUploadNew, btnLogout;
    private ResourceManager resourceManager;
    private List<StudyResource> resources;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_dashboard);

        resourceManager = ResourceManager.getInstance(this);

        listViewResources = findViewById(R.id.listViewResources);
        btnUploadNew = findViewById(R.id.btnUploadNew);
        btnLogout = findViewById(R.id.btnLogout);

        loadResources();

        btnUploadNew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AdminDashboardActivity.this,
                        UploadResourceActivity.class);
                startActivity(intent);
            }
        });

        listViewResources.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view,
                                           int position, long id) {
                showDeleteDialog(position);
                return true;
            }
        });

        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UserManager.getInstance().logout();
                Intent intent = new Intent(AdminDashboardActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "onResume called - reloading resources");
        loadResources();
    }


    private void loadResources() {
        resources = resourceManager.getAllResources();
        List<String> resourceInfo = new ArrayList<>();

        for (StudyResource resource : resources) {
            resourceInfo.add(resource.getTitle() + "\n" +
                    resource.getCategory() + " - " + resource.getFileType());
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, resourceInfo);
        listViewResources.setAdapter(adapter);
    }

    private void showDeleteDialog(int position) {
        StudyResource resource = resources.get(position);

        new AlertDialog.Builder(this)
                .setTitle("Delete Resource")
                .setMessage("Delete " + resource.getTitle() + "?")
                .setPositiveButton("Delete", (dialog, which) -> {
                    resourceManager.deleteResource(resource.getId());
                    loadResources();
                    Toast.makeText(this, "Resource deleted", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}
