package com.example.onclick;

import java.util.ArrayList;
import java.util.List;

public class UserManager {
    private static UserManager instance;
    private List<User> users;
    private User currentUser;

    private UserManager() {
        users = new ArrayList<>();
        initializeDefaultUsers();
    }

    public static UserManager getInstance() {
        if (instance == null) {
            instance = new UserManager();
        }
        return instance;
    }

    private void initializeDefaultUsers() {
        // 1 Admin account
        users.add(new User("admin", "admin123", "ADMIN"));

        // 3 Student accounts
        users.add(new User("student1", "pass123", "STUDENT"));
        users.add(new User("student2", "pass123", "STUDENT"));
        users.add(new User("student3", "pass123", "STUDENT"));
    }

    public boolean authenticate(String username, String password) {
        for (User user : users) {
            if (user.getUsername().equals(username) &&
                    user.getPassword().equals(password)) {
                currentUser = user;
                return true;
            }
        }
        return false;
    }

    public User getCurrentUser() {
        return currentUser;
    }

    public void logout() {
        currentUser = null;
    }
}
