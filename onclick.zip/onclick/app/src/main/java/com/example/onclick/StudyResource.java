package com.example.onclick;

import java.text.SimpleDateFormat;
import java.util.Date;

public class StudyResource {
    private String id;
    private String title;
    private String category;
    private String filePath;
    private String fileType;
    private String semester;
    private String uploadDate;

    // ✅ ADD THIS - NO-ARGUMENT CONSTRUCTOR (Required for Gson)
    public StudyResource() {
        this.uploadDate = getCurrentDate();
    }

    public StudyResource(String id, String title, String category,
                         String filePath, String fileType, String semester) {
        this.id = id;
        this.title = title;
        this.category = category;
        this.filePath = filePath;
        this.fileType = fileType;
        this.semester = semester;
        this.uploadDate = getCurrentDate();
    }

    private String getCurrentDate() {
        return new SimpleDateFormat("dd-MM-yyyy").format(new Date());
    }

    // Getters
    public String getId() { return id; }
    public String getTitle() { return title; }
    public String getCategory() { return category; }
    public String getFilePath() { return filePath; }
    public String getFileType() { return fileType; }
    public String getSemester() { return semester; }
    public String getUploadDate() { return uploadDate; }

    // ✅ ADD SETTERS (Gson uses these during deserialization)
    public void setId(String id) { this.id = id; }
    public void setTitle(String title) { this.title = title; }
    public void setCategory(String category) { this.category = category; }
    public void setFilePath(String filePath) { this.filePath = filePath; }
    public void setFileType(String fileType) { this.fileType = fileType; }
    public void setSemester(String semester) { this.semester = semester; }
    public void setUploadDate(String uploadDate) { this.uploadDate = uploadDate; }
}
