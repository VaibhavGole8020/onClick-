package com.example.onclick;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class ResourceManager {
    private static ResourceManager instance;
    private List<StudyResource> resources;
    private SharedPreferences sharedPreferences;
    private static final String PREFS_NAME = "OneClickPrefs";
    private static final String RESOURCES_KEY = "resources";
    private static final String TAG = "ResourceManager";
    private Gson gson;
    private Context appContext;

    private ResourceManager(Context context) {
        this.appContext = context.getApplicationContext();
        gson = new Gson();
        sharedPreferences = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);

        Log.d(TAG, "=== ResourceManager Initialization ===");

        // Always load first
        resources = loadResourcesFromStorage();
        Log.d(TAG, "Loaded " + resources.size() + " resources from storage");

        // ✅ ONLY initialize if completely empty (first run)
        if (resources.isEmpty()) {
            Log.d(TAG, "First run detected - initializing hardcoded resources");
            initializeHardcodedResources();
            saveResourcesToStorage();
        } else {
            Log.d(TAG, "Using existing resources from storage");
        }
    }

    public static synchronized ResourceManager getInstance(Context context) {
        if (instance == null) {
            instance = new ResourceManager(context);
        }
        return instance;
    }

    public static ResourceManager getInstance() {
        if (instance == null) {
            throw new RuntimeException("ResourceManager not initialized");
        }
        return instance;
    }

    public void reload() {
        Log.d(TAG, "=== RELOAD ===");
        resources = loadResourcesFromStorage();
        Log.d(TAG, "Reloaded " + resources.size() + " resources");
    }

    private void initializeHardcodedResources() {
        // ✅ DON'T clear - add to existing list
        Log.d(TAG, "Adding hardcoded resources (current count: " + resources.size() + ")");

        resources.add(new StudyResource("1", "Calculus Unit 1",
                "Maths Notes", "/storage/emulated/0/Documents/calculus1.pdf",
                "PDF", "Semester 1"));

        resources.add(new StudyResource("2", "Linear Algebra Solutions",
                "Tutorial Solutions", "/storage/emulated/0/Documents/linear_algebra.pdf",
                "PDF", "Semester 2"));

        resources.add(new StudyResource("3", "All Formulas",
                "Formulas", "/storage/emulated/0/Documents/formulas.pdf",
                "PDF", "All Units"));

        Log.d(TAG, "Hardcoded resources added (new count: " + resources.size() + ")");
    }

    private List<StudyResource> loadResourcesFromStorage() {
        String json = sharedPreferences.getString(RESOURCES_KEY, "");
        Log.d(TAG, "Loading from SharedPreferences, JSON length: " + json.length());

        if (json.isEmpty()) {
            return new ArrayList<>();
        }

        try {
            Type type = new TypeToken<List<StudyResource>>(){}.getType();
            List<StudyResource> loadedResources = gson.fromJson(json, type);

            if (loadedResources == null) {
                Log.e(TAG, "Gson returned null!");
                return new ArrayList<>();
            }

            Log.d(TAG, "✅ Loaded " + loadedResources.size() + " resources:");
            for (StudyResource res : loadedResources) {
                Log.d(TAG, "  - " + res.getTitle() + " (" + res.getCategory() + ")");
            }

            return loadedResources;
        } catch (Exception e) {
            Log.e(TAG, "❌ Error loading resources", e);
            return new ArrayList<>();
        }
    }

    private void saveResourcesToStorage() {
        try {
            String json = gson.toJson(resources);
            Log.d(TAG, "=== SAVE ===");
            Log.d(TAG, "Saving " + resources.size() + " resources");

            boolean success = sharedPreferences.edit()
                    .putString(RESOURCES_KEY, json)
                    .commit();

            if (success) {
                Log.d(TAG, "✅ Save successful");
            } else {
                Log.e(TAG, "❌ Save failed!");
            }
        } catch (Exception e) {
            Log.e(TAG, "❌ Error saving", e);
        }
    }

    public List<StudyResource> getAllResources() {
        reload();
        return new ArrayList<>(resources);
    }

    public List<StudyResource> getResourcesByCategory(String category) {
        reload();
        List<StudyResource> filtered = new ArrayList<>();
        for (StudyResource resource : resources) {
            if (resource.getCategory().equals(category)) {
                filtered.add(resource);
            }
        }
        return filtered;
    }

    public void addResource(StudyResource resource) {
        Log.d(TAG, "=== ADD ===");
        Log.d(TAG, "Before: " + resources.size());

        resources.add(resource);

        Log.d(TAG, "After: " + resources.size());
        Log.d(TAG, "Added: " + resource.getTitle());

        saveResourcesToStorage();
    }

    public void deleteResource(String resourceId) {
        Log.d(TAG, "=== DELETE ===");
        resources.removeIf(r -> r.getId().equals(resourceId));
        saveResourcesToStorage();
    }
}
