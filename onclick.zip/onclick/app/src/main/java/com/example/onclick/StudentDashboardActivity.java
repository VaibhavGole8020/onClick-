package com.example.onclick;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

public class StudentDashboardActivity extends AppCompatActivity {

    private Spinner spinnerCategory;
    private ListView listViewResources;
    private Button btnLogout, btnHome, btnNotes, btnAbout, btnContact, btnBackHome;
    private ResourceManager resourceManager;
    private List<StudyResource> currentResources;
    private static final String TAG = "StudentDashboard";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_dashboard);

        resourceManager = ResourceManager.getInstance(this);

        spinnerCategory = findViewById(R.id.spinnerCategory);
        listViewResources = findViewById(R.id.listViewResources);
        btnLogout = findViewById(R.id.btnLogout);
        btnHome = findViewById(R.id.btnHome);
        btnNotes = findViewById(R.id.btnNotes);
        btnAbout = findViewById(R.id.btnAbout);
        btnContact = findViewById(R.id.btnContact);
        btnBackHome = findViewById(R.id.btnBackHome);

        setupCategorySpinner();
        setupNavigationButtons();

        listViewResources.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                StudyResource resource = currentResources.get(position);
                Log.d(TAG, "Clicked resource: " + resource.getTitle());

                // ✅ DON'T pass URI via setData - just pass as String extra
                Intent intent = new Intent(StudentDashboardActivity.this, NotesActivity.class);
                intent.putExtra("resourceId", resource.getId());
                intent.putExtra("resourcePath", resource.getFilePath());
                intent.putExtra("resourceTitle", resource.getTitle());
                intent.putExtra("resourceCategory", resource.getCategory());
                intent.putExtra("resourceType", resource.getFileType());

                Log.d(TAG, "Starting NotesActivity for: " + resource.getTitle());
                startActivity(intent);
            }
        });


        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UserManager.getInstance().logout();
                Intent intent = new Intent(StudentDashboardActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });

        btnBackHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(StudentDashboardActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "=== onResume called ===");
        resourceManager.reload();
        if (spinnerCategory != null && spinnerCategory.getSelectedItem() != null) {
            String category = spinnerCategory.getSelectedItem().toString();
            loadResources(category);
        } else {
            loadResources("All");
        }
    }

    private void setupNavigationButtons() {
        btnHome.setOnClickListener(v -> Toast.makeText(this, "Home", Toast.LENGTH_SHORT).show());
        btnNotes.setOnClickListener(v -> {
            Toast.makeText(this, "Notes Section", Toast.LENGTH_SHORT).show();
            loadResources("All");
        });
        btnAbout.setOnClickListener(v -> Toast.makeText(this, "About OneClick", Toast.LENGTH_SHORT).show());
        btnContact.setOnClickListener(v -> Toast.makeText(this, "Contact Us", Toast.LENGTH_SHORT).show());
    }

    private void setupCategorySpinner() {
        String[] categories = {"All", "Maths Notes", "Tutorial Solutions",
                "Previous Year Question Papers", "Formulas"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, categories);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCategory.setAdapter(adapter);

        spinnerCategory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String category = (String) parent.getItemAtPosition(position);
                Log.d(TAG, "Category selected: " + category);
                loadResources(category);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });
    }

    private void loadResources(String category) {
        Log.d(TAG, "=== LOAD RESOURCES ===");
        Log.d(TAG, "Category: " + category);

        if ("All".equals(category)) {
            currentResources = resourceManager.getAllResources();
        } else {
            currentResources = resourceManager.getResourcesByCategory(category);
        }

        Log.d(TAG, "Loaded " + currentResources.size() + " resources");

        List<String> resourceTitles = new ArrayList<>();
        for (StudyResource resource : currentResources) {
            String displayText = resource.getTitle() + " (" + resource.getFileType() + ")";
            resourceTitles.add(displayText);
            Log.d(TAG, "  - " + displayText);
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, resourceTitles);
        listViewResources.setAdapter(adapter);

        if (currentResources.isEmpty()) {
            Toast.makeText(this, "No resources found for: " + category, Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Found " + currentResources.size() + " resources", Toast.LENGTH_SHORT).show();
        }
    }
}
