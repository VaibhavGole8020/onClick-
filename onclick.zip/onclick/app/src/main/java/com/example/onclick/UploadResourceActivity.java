package com.example.onclick;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class UploadResourceActivity extends AppCompatActivity {

    private static final String TAG = "UploadResource";
    private EditText etTitle, etSemester;
    private Spinner spinnerCategory;
    private TextView tvSelectedFile;
    private Button btnChooseFile, btnUpload, btnBackToDashboard, btnLogout;
    private Uri selectedFileUri;
    private String selectedFileName;
    private ResourceManager resourceManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_resource);

        Log.d(TAG, "UploadResourceActivity created");
        resourceManager = ResourceManager.getInstance(this);

        // Initialize views
        etTitle = findViewById(R.id.etTitle);
        etSemester = findViewById(R.id.etSemester);
        spinnerCategory = findViewById(R.id.spinnerCategory);
        tvSelectedFile = findViewById(R.id.tvSelectedFile);
        btnChooseFile = findViewById(R.id.btnChooseFile);
        btnUpload = findViewById(R.id.btnUpload);
        btnBackToDashboard = findViewById(R.id.btnBackToDashboard);
        btnLogout = findViewById(R.id.btnLogout);

        setupCategorySpinner();

        btnChooseFile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "Choose file clicked");
                openFilePicker();
            }
        });

        btnUpload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "Upload clicked");
                uploadResource();
            }
        });

        btnBackToDashboard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UserManager.getInstance().logout();
                Intent intent = new Intent(UploadResourceActivity.this, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                finish();
            }
        });
    }

    private void setupCategorySpinner() {
        String[] categories = {"Maths Notes", "Tutorial Solutions",
                "Previous Year Question Papers", "Formulas"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, categories);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCategory.setAdapter(adapter);
    }

    private void openFilePicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        startActivityForResult(intent, 100);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.d(TAG, "onActivityResult - requestCode: " + requestCode + ", resultCode: " + resultCode);

        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            selectedFileUri = data.getData();

            selectedFileName = getFileName(selectedFileUri);

            Log.d(TAG, "File selected: " + selectedFileUri.toString());
            Log.d(TAG, "File name: " + selectedFileName);

            tvSelectedFile.setText("Selected: " + selectedFileName);
        } else {
            Log.d(TAG, "File selection cancelled or failed");
        }
    }

    private String getFileName(Uri uri) {
        String result = null;
        if (uri.getScheme().equals("content")) {
            try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    int nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    if (nameIndex >= 0) {
                        result = cursor.getString(nameIndex);
                    }
                }
            } catch (Exception e) {
                Log.e(TAG, "Error getting file name", e);
            }
        }

        if (result == null) {
            result = uri.getLastPathSegment();
        }

        return result != null ? result : "unknown_file";
    }

    private String copyFileToInternalStorage(Uri sourceUri) throws IOException {
        String timestamp = String.valueOf(System.currentTimeMillis());
        String originalFileName = getFileName(sourceUri);
        String extension = "";

        if (originalFileName.contains(".")) {
            extension = originalFileName.substring(originalFileName.lastIndexOf("."));
        }

        String fileName = timestamp + extension;
        File destFile = new File(getFilesDir(), fileName);

        Log.d(TAG, "Copying file to: " + destFile.getAbsolutePath());

        InputStream inputStream = null;
        FileOutputStream outputStream = null;

        try {
            inputStream = getContentResolver().openInputStream(sourceUri);
            if (inputStream == null) {
                throw new IOException("Cannot open input stream");
            }

            outputStream = new FileOutputStream(destFile);

            byte[] buffer = new byte[4096];
            int length;
            long totalBytes = 0;

            while ((length = inputStream.read(buffer)) > 0) {
                outputStream.write(buffer, 0, length);
                totalBytes += length;
            }

            Log.d(TAG, "✅ File copied successfully: " + totalBytes + " bytes");
            return destFile.getAbsolutePath();

        } finally {
            if (inputStream != null) {
                try { inputStream.close(); } catch (IOException e) { }
            }
            if (outputStream != null) {
                try { outputStream.close(); } catch (IOException e) { }
            }
        }
    }

    private void uploadResource() {
        String title = etTitle.getText().toString().trim();
        String semester = etSemester.getText().toString().trim();
        String category = spinnerCategory.getSelectedItem().toString();

        Log.d(TAG, "Upload attempt:");
        Log.d(TAG, "  Title: " + title);
        Log.d(TAG, "  Semester: " + semester);
        Log.d(TAG, "  Category: " + category);
        Log.d(TAG, "  File URI: " + (selectedFileUri != null ? selectedFileUri.toString() : "NULL"));

        if (title.isEmpty() || semester.isEmpty() || selectedFileUri == null) {
            String error = "Missing fields";
            Log.e(TAG, error);
            Toast.makeText(this, "Please fill all fields and select a file",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            Log.d(TAG, "Copying file to internal storage...");
            String internalFilePath = copyFileToInternalStorage(selectedFileUri);
            Log.d(TAG, "File copied to: " + internalFilePath);

            String fileType = getFileType(selectedFileName);

            Log.d(TAG, "File type detected: " + fileType);

            String resourceId = String.valueOf(System.currentTimeMillis());
            Log.d(TAG, "Generated resource ID: " + resourceId);

            StudyResource resource = new StudyResource(resourceId, title, category,
                    internalFilePath, fileType, semester);

            int beforeCount = resourceManager.getAllResources().size();
            Log.d(TAG, "Resources count BEFORE adding: " + beforeCount);

            resourceManager.addResource(resource);

            int afterCount = resourceManager.getAllResources().size();
            Log.d(TAG, "Resources count AFTER adding: " + afterCount);

            if (afterCount > beforeCount) {
                Log.d(TAG, "✅ Resource successfully added!");
                Toast.makeText(this, "Resource uploaded successfully!", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Log.e(TAG, "❌ Resource NOT added - count unchanged!");
                Toast.makeText(this, "Upload failed - please try again", Toast.LENGTH_SHORT).show();
            }

        } catch (IOException e) {
            Log.e(TAG, "❌ Error copying file", e);
            Toast.makeText(this, "Failed to copy file: " + e.getMessage(),
                    Toast.LENGTH_LONG).show();
        }
    }

    private String getFileType(String fileName) {
        if (fileName == null) return "FILE";

        String lowerName = fileName.toLowerCase();

        if (lowerName.endsWith(".pdf")) return "PDF";
        if (lowerName.endsWith(".doc") || lowerName.endsWith(".docx")) return "DOC";
        if (lowerName.endsWith(".jpg") || lowerName.endsWith(".jpeg") ||
                lowerName.endsWith(".png") || lowerName.endsWith(".gif")) return "IMAGE";
        if (lowerName.endsWith(".txt")) return "TEXT";
        if (lowerName.endsWith(".xls") || lowerName.endsWith(".xlsx")) return "EXCEL";
        if (lowerName.endsWith(".ppt") || lowerName.endsWith(".pptx")) return "PPT";

        Log.w(TAG, "Unknown file type for: " + fileName);
        return "FILE";
    }
}
